import React from 'react'

export default function Menu_Card() {

  return (
    <div>
      <div>
        <h1>Enjoy Weekend</h1>
        <p></p>
        <div>Offer: Enjoy cook with you patnar</div>
        <div>recipy</div>
        

      </div>
    </div>
  )
}
